from typing import NewType
from typing import List

Obfuscated_String = NewType("Obfuscated_String", str)
Code_Block = NewType("Code_Block", List[List[str]])
